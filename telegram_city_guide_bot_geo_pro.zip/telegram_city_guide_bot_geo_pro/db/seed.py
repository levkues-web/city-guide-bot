import asyncio
import aiosqlite
from pathlib import Path

DB_PATH = Path(__file__).with_name("guide.db")
CITIES = ["Batumi", "Kobuleti"]

PLACES = {
    "Batumi": [
        dict(name="Batumi Boulevard", category="Парки", lat=41.6497, lon=41.6367,
             description="Зелёная набережная с пальмами, велодорожками и скульптурами.",
             address="Batumi Boulevard, Batumi", hours="24/7", rating=4.7, url="",
             kids_friendly=1, dog_friendly=1, price_level=1),
        dict(name="Ali & Nino Statue", category="Достопримечательности", lat=41.6515, lon=41.6347,
             description="Динамическая скульптура любви — символ Батуми у моря.",
             address="Batumis bulvari, Batumi", hours="Круглосуточно", rating=4.6, url="",
             kids_friendly=1, dog_friendly=1, price_level=0),
        dict(name="Batumi Botanical Garden", category="Музеи", lat=41.6943, lon=41.7205,
             description="Грандиозный ботанический сад над Чёрным морем, виды и экотропы.",
             address="Mtsvane Kontskhi, Batumi", hours="09:00–19:00", rating=4.8, url="https://bbg.ge",
             kids_friendly=1, dog_friendly=0, price_level=2),
        dict(name="Piazza Batumi", category="Достопримечательности", lat=41.6519, lon=41.6407,
             description="Итальянская площадь с кафе и живой музыкой, уютный вечерний вайб.",
             address="Piazza Square, Batumi", hours="08:00–00:00", rating=4.5, url="",
             kids_friendly=1, dog_friendly=0, price_level=2),
        dict(name="Gonio Fortress", category="Музеи", lat=41.5807, lon=41.5713,
             description="Античная крепость римского периода в пригороде Батуми.",
             address="Gonio-Apsaros Fortress, Kvariati Road", hours="10:00–18:00", rating=4.6, url="",
             kids_friendly=1, dog_friendly=0, price_level=2),
        dict(name="Retro Restaurant", category="Питание", lat=41.6441, lon=41.6394,
             description="Хачапури по-аджарски и грузинская классика.",
             address="Khimshiashvili St 1/5, Batumi", hours="10:00–23:00", rating=4.5, url="",
             kids_friendly=1, dog_friendly=0, price_level=2),
        dict(name="Batumi Central Park Gym", category="Спортзалы", lat=41.6475, lon=41.6349,
             description="Уличные тренажёры и площадка для воркаута в парке.",
             address="Central Park, Batumi", hours="24/7", rating=4.3, url="",
             kids_friendly=1, dog_friendly=1, price_level=0),
        dict(name="Event Hall Batumi", category="События", lat=41.6408, lon=41.6321,
             description="Концерты, фестивали и городские события у моря.",
             address="Seaside area, Batumi", hours="Зависит от события", rating=4.4, url="",
             kids_friendly=1, dog_friendly=0, price_level=0),
    ],
    "Kobuleti": [
        dict(name="Kobuleti Beach", category="Достопримечательности", lat=41.8146, lon=41.7756,
             description="Длинный галечный пляж, спокойное море и релакс.",
             address="Kobuleti Seaside", hours="24/7", rating=4.5, url="",
             kids_friendly=1, dog_friendly=1, price_level=0),
        dict(name="Kobuleti Boulevard", category="Парки", lat=41.8215, lon=41.7777,
             description="Приятная прогулочная зона вдоль моря, детские площадки и кафе.",
             address="Agmashenebeli Ave, Kobuleti", hours="Круглосуточно", rating=4.4, url="",
             kids_friendly=1, dog_friendly=1, price_level=1),
        dict(name="Petra Fortress (Tsikhisdziri)", category="Музеи", lat=41.7745, lon=41.7559,
             description="Византийская крепость на скале с видом на море.",
             address="Tsikhisdziri, Adjara", hours="10:00–18:00", rating=4.6, url="",
             kids_friendly=1, dog_friendly=0, price_level=2),
        dict(name="Restaurant Taraghana", category="Питание", lat=41.8206, lon=41.7796,
             description="Домашняя грузинская кухня, хачапури и свежая рыба.",
             address="Agmashenebeli Ave, Kobuleti", hours="10:00–22:00", rating=4.4, url="",
             kids_friendly=1, dog_friendly=0, price_level=2),
        dict(name="Kobuleti Central Park", category="Парки", lat=41.8187, lon=41.7813,
             description="Зелёная зона для прогулок и отдыха в центре.",
             address="Kutaisi St, Kobuleti", hours="08:00–22:00", rating=4.3, url="",
             kids_friendly=1, dog_friendly=0, price_level=0),
        dict(name="Kobuleti Fitness Club", category="Спортзалы", lat=41.8159, lon=41.7792,
             description="Небольшой тренажёрный зал рядом с набережной.",
             address="Near Agmashenebeli Ave, Kobuleti", hours="08:00–22:00", rating=4.2, url="",
             kids_friendly=1, dog_friendly=0, price_level=2),
        dict(name="Kobuleti Culture Center", category="События", lat=41.8181, lon=41.7798,
             description="Концерты, локальные фестивали и городские мероприятия.",
             address="City Center, Kobuleti", hours="По расписанию", rating=4.2, url="",
             kids_friendly=1, dog_friendly=0, price_level=0),
    ],
}

async def seed_basic_data():
    async with aiosqlite.connect(DB_PATH) as db:
        with open(Path(__file__).with_name("init.sql"), "r", encoding="utf-8") as f:
            await db.executescript(f.read())
        await db.commit()

        for city in CITIES:
            await db.execute("INSERT OR IGNORE INTO cities(name) VALUES (?)", (city,))
        await db.commit()

        city_id = {}
        async with db.execute("SELECT id, name FROM cities") as cursor:
            async for row in cursor:
                cid, name = row
                city_id[name] = cid

        for city, places in PLACES.items():
            cid = city_id[city]
            for p in places:
                await db.execute("""
                    INSERT INTO places(city_id, name, category, lat, lon, description, address, hours, rating, url, kids_friendly, dog_friendly, price_level)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
                """, (cid, p["name"], p["category"], p["lat"], p["lon"], p["description"], p["address"], p["hours"], p["rating"], p["url"], p["kids_friendly"], p["dog_friendly"], p["price_level"]))
        await db.commit()
    print("Seed complete:", DB_PATH)

if __name__ == "__main__":
    import asyncio
    asyncio.run(seed_basic_data())
