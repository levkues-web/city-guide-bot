PRAGMA journal_mode = WAL;

CREATE TABLE IF NOT EXISTS cities (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS places (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    city_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    lat REAL NOT NULL,
    lon REAL NOT NULL,
    description TEXT DEFAULT '',
    address TEXT DEFAULT '',
    hours TEXT DEFAULT '',
    rating REAL DEFAULT 0,
    url TEXT DEFAULT '',
    kids_friendly INTEGER DEFAULT 0,
    dog_friendly INTEGER DEFAULT 0,
    price_level INTEGER DEFAULT 0,
    FOREIGN KEY (city_id) REFERENCES cities (id)
);

CREATE TABLE IF NOT EXISTS favorites (
    user_id INTEGER NOT NULL,
    place_id INTEGER NOT NULL,
    PRIMARY KEY (user_id, place_id),
    FOREIGN KEY (place_id) REFERENCES places(id)
);

CREATE TABLE IF NOT EXISTS user_prefs (
    user_id INTEGER PRIMARY KEY,
    lang TEXT DEFAULT 'ru',
    kids_friendly INTEGER DEFAULT 0,
    dog_friendly INTEGER DEFAULT 0,
    price_level INTEGER DEFAULT 0
);
